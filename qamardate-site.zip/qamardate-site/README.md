# QamarDate

Static website that converts a Gregorian date of birth into its Hijri (Islamic) date.
Conversion runs in the browser using the built-in Umm al-Qura calendar (`Intl`, `islamic-umalqura`).
No server, no database, no API keys.

## Local test
Open `index.html` in a browser. No build step is needed.

## Deploy on GitHub Pages
1. Create a public repository, for example `qamardate`.
2. Upload `index.html` and this `README.md` to the repository root (or push with git).
3. Go to Settings > Pages.
4. Under "Build and deployment", set Source to "Deploy from a branch", Branch to `main`, folder `/ (root)`, then Save.
5. After about a minute the site is live at `https://<your-username>.github.io/qamardate/`.

## Notes
- Calculated dates (Umm al-Qura) can differ by one day from local moon-sighting announcements.
- Supported range: dates from 1 January 1900 to today (Hijri years 1300–1600 AH).
- Google Fonts are loaded from fonts.googleapis.com. The birth date is never included in that request.
